import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="Akari-Codes",
    version="1.1",
    author="Akari",
    author_email="akari+cachy@astil-industries.com",
    description="Cachy is a simple Module I have written for my own ease of use, and I decided to release it as a public module so other people can use it. Cachy allows use to add pass data into it and saves it to a single index but can also save the entire index or a single data from the index when using the save feature you can have multiple programs share variabls without having to setup a local data tunnel also allows you to have files saved in the cache meaning you can have the system load a cached file when it isnt in the index that was from a previous session into the current session.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Akari-Codes/Cachy-Python-Module",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
